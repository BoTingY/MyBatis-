package com.powernode.bank.exceptions;

/**
 * 转账异常
 */
public class TransferException extends Exception{
    public TransferException(){}
    public TransferException(String msg){

    }
}
